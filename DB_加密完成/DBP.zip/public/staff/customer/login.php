<?PHP

	require_once('../../../private/initialize.php');

    $first_name = $_POST['first_name'];
    $passowrd = $_POST['password'];

    if ($first_name && $passowrd){
             $sql = "select * from customer where first_name = '$first_name' and password='$passowrd'";//检测数据库是否有对应的username和password的sql
             $result = mysqli_query($db,$sql);
             $passenger_id = $_GET['id'];
             $rows=mysqli_num_rows($result);
             if($rows){
             		
                   redirect_to(url_for('/staff/customer/show.php?id=' . h(u($customer['passenger_id']))));//如果成功跳转至welcome.html页面
                   exit;
             }else{
                echo "wrong name or password";
             }
    }else{
                echo "Imcomplete";
                
    }

?>
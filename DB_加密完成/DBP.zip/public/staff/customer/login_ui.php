<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>登陆</title>
    </head>
    <body>
        <form name="login" action="login.php" method="post">
                <p>用户名<input type=text name="first_name"></p>
                <p>密 码<input type=password name="password"></p>
                <p><input type="submit" name="submit" value="登录"></p>
            </form>
    </body>
</html>
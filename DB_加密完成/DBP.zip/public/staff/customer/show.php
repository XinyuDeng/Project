<?php require_once('../../../private/initialize.php'); ?>

<?php
// $id = isset($_GET['id']) ? $_GET['id'] : '1';
$passenger_id = $_GET['id'] ?? '1'; // PHP > 7.0

$customer = find_customer_by_id($passenger_id);

?>

<?php $page_title = 'Show Customer'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

  <a class="back-link" href="<?php echo url_for('/staff/customer/index.php'); ?>">&laquo; Back to List</a>

  <div class="Customer show">

    <h1>Customer: <?php echo h($customer['first_name']);echo " "; echo h($customer['last_name']); ?></h1>

    <div class="attributes">
      <dl>
        <dt>nationality</dt>
        <dd><?php echo h($customer['nationality']); ?></dd>
      </dl>
      <dl>
        <dt>gender</dt>
        <dd><?php echo h($customer['gender']); ?></dd>
      </dl>
      <dl>
        <dt>addr_stree</dt>
        <dd><?php echo h($customer['addr_stree']); ?></dd>
      </dl>
      <dl>
        <dt>addr_city</dt>
        <dd><?php echo h($customer['addr_city']); ?></dd>
      </dl>
      <dl>
        <dt>addr_state</dt>
        <dd><?php echo h($customer['addr_state']); ?></dd>
      </dl>
      <dl>
        <dt>zipcode</dt>
        <dd><?php echo h($customer['zipcode']); ?></dd>
      </dl>
      <dl>
        <dt>email</dt>
        <dd><?php echo h($customer['email']); ?></dd>
      </dl>
      <dl>
        <dt>contact_num</dt>
        <dd><?php echo h($customer['contact_num']); ?></dd>
      </dl>
    </div>

  </div>

</div>

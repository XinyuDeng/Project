<?php

require_once('../../../private/initialize.php');

if(is_post_request()) {

    $aircraft = [];
    $aircraft['aircraft_id'] = $_POST['aircraft_id'] ?? '';
    $aircraft['model_name'] = $_POST['model_name'] ?? '';
    $aircraft['manufacturer'] = $_POST['manufacturer'] ?? '';
    $aircraft['engine_num'] = $_POST['engine_num'] ?? '';
    $aircraft['fleet_num'] = $_POST['fleet_num'] ?? '';
    $aircraft['airline_id'] = $_POST['airline_id'] ?? '';

    $result = insert_aircraft($aircraft);
    if($result === true) {
        $new_id = mysqli_insert_id($db);
        redirect_to(url_for('/staff/aircraft/show.php?id=' . $new_id));
    } else {
        $errors = $result;
    }

} else {
    // display the blank form
    $aircraft = [];
    $aircraft['aircraft_id'] = '';
    $aircraft['model_name'] = '';
    $aircraft['manufacturer'] = '';
    $aircraft['engine_num'] = '';
    $aircraft['fleet_num'] = '';
    $aircraft['airline_id'] = '';
}

$aircraft_set = find_all_aircraft();
$aircraft_count = mysqli_num_rows($aircraft_set) + 1;
mysqli_free_result($aircraft_set);

?>

<?php $page_title = 'Add Aircraft'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">

    <a class="back-link" href="<?php echo url_for('/staff/aircraft/index.php'); ?>">&laquo; Back to List</a>

    <div class="Add Aircraft">
        <h1>Add Aircraft</h1>

        <?php echo display_errors($errors); ?>

        <form action="<?php echo url_for('/staff/aircraft/new.php'); ?>" method="post">
            <dl>
                <dt>aircraft_id</dt>
                <dd><input type="number" name="aircraft_id" min="1" max="99999"
                           value="<?php echo h($aircraft['aircraft_id']); ?>" /></dd>
            </dl>

            <dl>
                <dt>model_name</dt>
                <dd><input type="text" name="model_name" value="<?php echo h($aircraft['model_name']); ?>" /></dd>
            </dl>

            <dl>
                <dt>manufacturer</dt>
                <dd><input type="text" name="manufacturer" value="<?php echo h($aircraft['manufacturer']); ?>" /></dd>
            </dl>

            <dl>
                <dt>engine_num</dt>
                <dd><input type="number" name="engine_num" min="1" max="999"
                           value="<?php echo h($aircraft['engine_num']); ?>" /></dd>
            </dl>

            <dl>
                <dt>fleet_num</dt>
                <dd><input type="number" name="fleet_num" min="1" max="99999"
                           value="<?php echo h($aircraft['fleet_num']); ?>" /></dd>
            </dl>

            <dl>
                <dt>airline_id</dt>
                <dd><input type="number" name="airline_id" min="1" max="9999"
                           value="<?php echo h($aircraft['airline_id']); ?>" /></dd>
            </dl>


            <div id="operations">
                <input type="submit" value="Add Aircraft" />
            </div>
        </form>

    </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>


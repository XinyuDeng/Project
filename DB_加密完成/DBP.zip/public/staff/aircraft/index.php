<?php require_once('../../../private/initialize.php'); ?>

<?php

$aircraft_set = find_all_aircraft();

?>

<?php $page_title = 'Aircrafts'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
    <div class="Aircraft listing">
        <h1>Aircrafts</h1>

        <div class="actions">
            <a class="action" href="<?php echo url_for('/staff/aircraft/new.php'); ?>">Add New Aircraft</a>
        </div>

        <table class="list">
            <tr>
                <th>aircraft_id</th>
                <th>model_name</th>
                <th>manufacturer</th>
                <th>engine_num</th>
                <th>fleet_num</th>
                <th>airline_id</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>

            <?php while($aircraft = mysqli_fetch_assoc($aircraft_set)) { ?>
                <tr>
                    <td><?php echo h($aircraft['aircraft_id']); ?></td>
                    <td><?php echo h($aircraft['model_name']); ?></td>
                    <td><?php echo h($aircraft['manufacturer']); ?></td>
                    <td><?php echo h($aircraft['engine_num']); ?></td>
                    <td><?php echo h($aircraft['fleet_num']); ?></td>
                    <td><?php echo h($aircraft['airline_id']); ?></td>
                    <td><a class="action" href="<?php echo url_for('/staff/aircraft/show.php?id=' . h(u($aircraft['aircraft_id']))); ?>">View</a></td>
                    <td><a class="action" href="<?php echo url_for('/staff/aircraft/edit.php?id=' . h(u($aircraft['aircraft_id']))); ?>">Edit</a></td>
                    <td><a class="action" href="<?php echo url_for('/staff/aircraft/delete.php?id=' . h(u($aircraft['aircraft_id']))); ?>">Delete</a></td>
                </tr>
            <?php } ?>
        </table>

        <?php
        mysqli_free_result($aircraft_set);
        ?>
    </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>

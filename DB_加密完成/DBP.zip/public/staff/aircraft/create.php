<?php

require_once('../../../private/initialize.php');

if(is_post_request()){
    // Handle form values sent by new.php

    $aircraft_id = $_POST['aircraft_id'] ?? '';
    $model_name = $_POST['model_name'] ?? '';
    $manufacturer = $_POST['manufacturer'] ?? '';
    $engine_num = $_POST['engine_num'] ?? '';
    $fleet_num = $_POST['fleet_num'] ?? '';
    $airline_id = $_POST['airline_id'] ?? '';


    $result = insert_customer($aircraft_id,$model_name,$manufacturer,$engine_num,$fleet_num,$airline_id);
    $new_id = mysqli_insert_id($db);
    redirect_to(url_for('/staff/aircraft/show.php?id=' . $new_id));
}else{
    redirect_to(url_for('/staff/aircraft/new.php'));
}

?>

<?php

require_once('../../../private/initialize.php');

if(!isset($_GET['id'])) {
    redirect_to(url_for('/staff/aircraft/index.php'));
}

$aircraft_id = $_GET['id'];

if(is_post_request()) {

    // Handle form values sent by new.php

    $aircraft = [];
    $aircraft['aircraft_id'] = $aircraft_id;
    $aircraft['model_name'] = $_POST['model_name'] ?? '';
    $aircraft['manufacturer'] = $_POST['manufacturer'] ?? '';
    $aircraft['engine_num'] = $_POST['engine_num'] ?? '';
    $aircraft['fleet_num'] = $_POST['fleet_num'] ?? '';
    $aircraft['airline_id'] = $_POST['airline_id'] ?? '';

    $result = update_aircraft($aircraft);
    if($result === true) {
        redirect_to(url_for('/staff/aircraft/show.php?id=' . $aircraft_id));
    } else {
        $errors = $result;
    }

} else {

    $aircraft = find_aircraft_by_id($aircraft_id);

}

$aircraft_set = find_all_aircraft();
$aircraft_count = mysqli_num_rows($aircraft_set);
mysqli_free_result($aircraft_set);

?>

<?php $page_title = 'Edit Aircraft'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

    <div id="content">

        <a class="back-link" href="<?php echo url_for('/staff/aircraft/index.php'); ?>">&laquo; Back to List</a>

        <div class="aircraft edit">
            <h1>Edit Aircraft</h1>

            <?php echo display_errors($errors); ?>

            <form action="<?php echo url_for('/staff/aircraft/edit.php?id=' . h(u($aircraft_id))); ?>" method="post">
                <dl>
                    <dt>model_name</dt>
                    <dd><input type="text" name="model_name" value="<?php echo h($aircraft['model_name']); ?>" /></dd>
                </dl>

                <dl>
                    <dt>manufacturer</dt>
                    <dd><input type="text" name="manufacturer" value="<?php echo h($aircraft['manufacturer']); ?>" /></dd>
                </dl>

                <dl>
                    <dt>engine_num</dt>
                    <dd><input type="number" name="engine_num" min="1" max="999"
                               value="<?php echo h($aircraft['engine_num']); ?>" /></dd>
                </dl>

                <dl>
                    <dt>fleet_num</dt>
                    <dd><input type="number" name="fleet_num" min="1" max="99999"
                               value="<?php echo h($aircraft['fleet_num']); ?>" /></dd>
                </dl>

                <dl>
                    <dt>airline_id</dt>
                    <dd><input type="number" name="airline_id" min="1" max="9999"
                               value="<?php echo h($aircraft['airline_id']); ?>" /></dd>
                </dl>

                <div id="operations">
                    <input type="submit" value="Edit Aircraft" />
                </div>
            </form>

        </div>

    </div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
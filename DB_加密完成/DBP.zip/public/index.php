<!doctype html>

<html lang="en">
  <head>
    <title>SAME</title>
    <meta charset="utf-8">
  </head>

  <body>

    <h1>SAME: SAFE FLY MANAGEMENT EXCELLENCE</h1>

  </body>
</html>

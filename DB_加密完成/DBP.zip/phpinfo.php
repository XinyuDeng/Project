<?php
	phpinfo();
?>
<footer>
  &copy; <?php echo date('Y'); ?> SAFE FLY MANAGEMENT EXCELLENCE
</footer>

</body>
</html>

<?php
  db_disconnect($db);
?>
